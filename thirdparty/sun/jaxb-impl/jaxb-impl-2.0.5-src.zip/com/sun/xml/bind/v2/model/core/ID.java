package com.sun.xml.bind.v2.model.core;

/**
 * @author Kohsuke Kawaguchi
 */
public enum ID {
    ID,IDREF,NONE
}
